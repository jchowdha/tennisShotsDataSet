import os
import subprocess
import sys

def convert_png_to_jpeg(folder_path):
    """
    Converts all .png files in the specified folder to .jpeg format
    using the 'sips' tool on macOS.

    Args:
        folder_path (str): The path to the folder containing the .png files.
    """
    if not os.path.isdir(folder_path):
        print(f"Error: Folder '{folder_path}' not found.")
        return

    print(f"Starting conversion in folder: {folder_path}")
    converted_count = 0

    # List all files in the given folder
    for i, filename in enumerate(os.listdir(folder_path)):
        # Check if the file is a PNG image
        if filename.lower().endswith(".png"):
            png_file_path = os.path.join(folder_path, filename)
            # Construct the output JPEG filename
            jpeg_filename = f"File{i+1}.jpeg"
            jpeg_file_path = os.path.join(folder_path, jpeg_filename)

            # Construct the sips command
            # 'sips -s format jpeg' sets the output format to JPEG
            # '--out' specifies the output file path
            command = ["sips", "-s", "format", "jpeg", png_file_path, "--out", jpeg_file_path]

            try:
                # Execute the sips command
                # capture_output=True and text=True capture stdout/stderr as text
                # check=True raises an exception if the command returns a non-zero exit code
                subprocess.run(command, check=True, capture_output=True, text=True)
                print(f"Converted '{filename}' to '{jpeg_filename}'")
                converted_count += 1
            except subprocess.CalledProcessError as e:
                print(f"Error converting '{filename}': {e}")
                print(f"Stdout: {e.stdout}")
                print(f"Stderr: {e.stderr}")
            except FileNotFoundError:
                print("Error: 'sips' command not found. This script is for macOS only.")
                return

    print(f"\nConversion complete. Converted {converted_count} PNG files to JPEG.")


if __name__ == "__main__":
    # Check if a command-line argument (the folder path) is provided
    if len(sys.argv) > 1:
        # sys.argv[0] is the script name itself, sys.argv[1] is the first argument
        target_folder = sys.argv[1]
    else:
        print("Usage: python convert_images.py <relative_path_to_folder>")
        print("Example: python convert_images.py ./my_images")
        print("         (This will look for PNGs in a folder named 'my_images' in the current directory)")
        sys.exit(1) # Exit with an error code if no argument is provided

    convert_png_to_jpeg(target_folder)
